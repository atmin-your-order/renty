<?php

declare(strict_types=1);

namespace ref\libNpcDialogue;

final class DialogueStore{

	/** @var NpcDialogue[][] */
	public static array $dialogueQueue = [];
}