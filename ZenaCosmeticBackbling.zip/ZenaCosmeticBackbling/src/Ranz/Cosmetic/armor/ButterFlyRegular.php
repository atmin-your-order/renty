<?php

namespace Ranz\Cosmetic\armor;

use pocketmine\item\Armor;
use pocketmine\item\ArmorTypeInfo;
use pocketmine\item\ItemIdentifier;
use pocketmine\inventory\ArmorInventory;

use customiesdevs\customies\item\ItemComponents;
use customiesdevs\customies\item\CreativeInventoryInfo;
use customiesdevs\customies\item\ItemComponentsTrait;

class ButterFlyRegular extends Armor implements ItemComponents {
  use ItemComponentsTrait;
  
  public function __construct(ItemIdentifier $identifier, string $name = "Unknown"){
		parent::__construct($identifier, $name, new ArmorTypeInfo(9, 592, ArmorInventory::SLOT_CHEST, 3, true));
		$this->initComponent("hivebackbling:butterfly_wings_regular", new CreativeInventoryInfo(CreativeInventoryInfo::CATEGORY_EQUIPMENT, CreativeInventoryInfo::GROUP_CHESTPLATE));
	}
}