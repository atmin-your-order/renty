<?php

namespace Ranz\Cosmetic;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\resourcepacks\ZippedResourcePack;
use ReflectionClass;

use Ranz\Cosmetic\armor\AngelBlack;
use Ranz\Cosmetic\armor\AngelPink;
use Ranz\Cosmetic\armor\AngelWhite;
use Ranz\Cosmetic\armor\AxolotlEndolotl;
use Ranz\Cosmetic\armor\AxolotlPink;
use Ranz\Cosmetic\armor\AxolotlSunflower;
use Ranz\Cosmetic\armor\BearBlue;
use Ranz\Cosmetic\armor\BearBrown;
use Ranz\Cosmetic\armor\BearPink;
use Ranz\Cosmetic\armor\ButterFlyBlue;
use Ranz\Cosmetic\armor\ButterFlyPink;
use Ranz\Cosmetic\armor\ButterFlyRegular;
use Ranz\Cosmetic\armor\DemonBlaze;
use Ranz\Cosmetic\armor\DemonBones;
use Ranz\Cosmetic\armor\DemonEnder;
use Ranz\Cosmetic\armor\DemonRed;
use Ranz\Cosmetic\armor\EnderWings;
use Ranz\Cosmetic\armor\LunarBlue;
use Ranz\Cosmetic\armor\LunarGreen;
use Ranz\Cosmetic\armor\LunarRegular;
use Ranz\Cosmetic\armor\SoaringHeartBlack;
use Ranz\Cosmetic\armor\SoaringHeartPink;
use Ranz\Cosmetic\armor\Solar;
use Ranz\Cosmetic\armor\SteamPunk;
use Ranz\Cosmetic\armor\TentaclesBlue;
use Ranz\Cosmetic\armor\TentaclesGreen;
use Ranz\Cosmetic\armor\TentaclesMagma;
use Ranz\Cosmetic\armor\TentaclesPurple;
use Ranz\Cosmetic\armor\Turtle;

use customiesdevs\customies\item\CustomiesItemFactory;

class Loader extends PluginBase 
{
  
  public function onEnable(): void 
  {
    CustomiesItemFactory::getInstance()->registerItem(AngelBlack::class, "hivebackbling:angel_wings_black", "AngelBlack");
    CustomiesItemFactory::getInstance()->registerItem(AngelPink::class, "hivebackbling:angel_wings_pink", "AngelPink");
    CustomiesItemFactory::getInstance()->registerItem(AngelWhite::class, "hivebackbling:angel_wings_white", "AngelWhite");
    CustomiesItemFactory::getInstance()->registerItem(AxolotlEndolotl::class, "hivebackbling:axolotl_plush_endolotl", "AxolotlEndolotl");
    CustomiesItemFactory::getInstance()->registerItem(AxolotlPink::class, "hivebackbling:axolotl_plush_pink", "AxolotlPink");
    CustomiesItemFactory::getInstance()->registerItem(AxolotlSunflower::class, "hivebackbling:axolotl_plush_sunflower", "AxolotlSunflower");
    CustomiesItemFactory::getInstance()->registerItem(BearBlue::class, "hivebackbling:cuddle_bear_blue", "BearBlue");
    CustomiesItemFactory::getInstance()->registerItem(BearBrown::class, "hivebackbling:cuddle_bear_brown", "BearBrown");
    CustomiesItemFactory::getInstance()->registerItem(BearPink::class, "hivebackbling:cuddle_bear_pink", "BearPink");
    CustomiesItemFactory::getInstance()->registerItem(ButterFlyBlue::class, "hivebackbling:butterfly_wings_blue", "ButterFlyBlue");
    CustomiesItemFactory::getInstance()->registerItem(ButterFlyPink::class, "hivebackbling:butterfly_wings_pink", "ButterFlyPink");
    CustomiesItemFactory::getInstance()->registerItem(ButterFlyRegular::class, "hivebackbling:butterfly_wings_regular", "ButterFlyRegular");
    CustomiesItemFactory::getInstance()->registerItem(DemonBlaze::class, "hivebackbling:demon_wings_blaze", "DemonBlaze");
    CustomiesItemFactory::getInstance()->registerItem(DemonBones::class, "hivebackbling:demon_wings_bones", "DemonBones");
    CustomiesItemFactory::getInstance()->registerItem(DemonEnder::class, "hivebackbling:demon_wings_ender", "DemonEnder");
    CustomiesItemFactory::getInstance()->registerItem(DemonRed::class, "hivebackbling:demon_wings_red", "DemonRed");
    CustomiesItemFactory::getInstance()->registerItem(EnderWings::class, "hivebackbling:ender_wings", "EnderWings");
    CustomiesItemFactory::getInstance()->registerItem(LunarBlue::class, "hivebackbling:lunar_wings_blue", "LunarBlue");
    CustomiesItemFactory::getInstance()->registerItem(LunarGreen::class, "hivebackbling:lunar_wings_green", "LunarGreen");
    CustomiesItemFactory::getInstance()->registerItem(LunarRegular::class, "hivebackbling:lunar_wings_regular", "LunarRegular");
    CustomiesItemFactory::getInstance()->registerItem(SoaringHeartBlack::class, "hivebackbling:soaring_heart_black", "SoaringHeartBlack");
    CustomiesItemFactory::getInstance()->registerItem(SoaringHeartPink::class, "hivebackbling:soaring_heart_pink", "SoaringHeartPink");
    CustomiesItemFactory::getInstance()->registerItem(Solar::class, "hivebackbling:solar_system", "Solar");
    CustomiesItemFactory::getInstance()->registerItem(SteamPunk::class, "hivebackbling:steampunk_wings", "SteamPunk");
    CustomiesItemFactory::getInstance()->registerItem(TentaclesBlue::class, "hivebackbling:kraken_tentacles_blue", "TentaclesBlue");
    CustomiesItemFactory::getInstance()->registerItem(TentaclesGreen::class, "hivebackbling:kraken_tentacles_green", "TentaclesGreen");
    CustomiesItemFactory::getInstance()->registerItem(TentaclesMagma::class, "hivebackbling:kraken_tentacles_magma", "TentaclesMagma");
    CustomiesItemFactory::getInstance()->registerItem(TentaclesPurple::class, "hivebackbling:kraken_tentacles_purple", "TentaclesPurple");
    CustomiesItemFactory::getInstance()->registerItem(Turtle::class, "hivebackbling:turtle_shell", "Turtle");
    
    $this->saveResource("ZenaBackbling.zip", true);
	$manager = $this->getServer()->getResourcePackManager();
	$pack = new ZippedResourcePack($this->getDataFolder() . "ZenaBackbling.zip");
	$reflection = new ReflectionClass($manager);
	$property = $reflection->getProperty("resourcePacks");
	$property->setAccessible(true);
	$currentResourcePacks = $property->getValue($manager);
	$currentResourcePacks[] = $pack;
	$property->setValue($manager, $currentResourcePacks);
	$property = $reflection->getProperty("uuidList");
	$property->setAccessible(true);
	$currentUUIDPacks = $property->getValue($manager);
	$currentUUIDPacks[strtolower($pack->getPackId())] = $pack;
	$property->setValue($manager, $currentUUIDPacks);
	$property = $reflection->getProperty("serverForceResources");
	$property->setAccessible(true);
	$property->setValue($manager, true);
  }
}