<?php

declare(strict_types=1);

namespace NhanAZ\libBedrock;

use pocketmine\plugin\PluginBase;

/**
 * @package NhanAZ\libBedrock
 *
 * 🌈 A library that provides common features for the PocketMine-MP plugin.
 */
class libBedrock extends PluginBase {
}
