Hi! I'm really glad you're interested in contributing to the ProfanityFilter.

Before submitting your contribution, make sure to take a moment and read through the following guidelines:

- [Code of Conduct](https://github.com/NhanAZ/libBedrock/blob/master/CODE_OF_CONDUCT.md)
